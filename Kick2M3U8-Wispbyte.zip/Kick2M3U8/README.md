# Kick2M3U8 — Wispbyte uyumlu 5 kanallı HLS proxy ve yönetim paneli

Sıfır bağımlılık (yalnızca Node.js ≥ 20 yerleşik modülleri). `npm install` gerekmez.
FFmpeg isteğe bağlıdır; yoksa proxy modu çalışır.

## Önemli sınırlar (dürüst notlar)
- Kick kullanıcı adı tek başına yayın URL'si vermez. `CHANNEL_n_SOURCE_URL` içine **izin verilen, erişebildiğiniz gerçek HLS (.m3u8) adresini** siz girersiniz. Kick erişim kontrolleri/DRM aşılmaz. Kaynak yoksa kanal listeden çıkar, uydurma playlist üretilmez.
- Gerçek Kick kaynağıyla canlı test **yapılmadı**; testler yerel sahte HLS kaynağıyla çalışır.
- Wispbyte limitleri (RAM/disk/CPU/FFmpeg varlığı) doğrulanmadı; varsayımdır. Başlangıçta `FFmpeg: ...` satırı log'da görünür.
- DNS-rebinding'e karşı tam koruma yoktur (istek öncesi DNS doğrulanır, IP sabitlenmez).
- CPU yüzdesi ölçülmez: "Desteklenmiyor" gösterilir.

## Wispbyte'a yükleme
1. ZIP'i açıp dosyaları sunucunun dosya yöneticisine yükleyin (`node_modules` gerekmez).
2. Startup komutu: `npm start` (ana dosya `server.js`).
3. Environment Variables bölümüne `.env.example` içindeki değişkenleri girin (en az `ADMIN_PASSWORD`, `CHANNEL_1_NAME`, `CHANNEL_1_SOURCE_URL`, `PUBLIC_BASE_URL`). ENV değişince Wispbyte panelinden yeniden başlatın.
4. Panel: `PUBLIC_BASE_URL/` → parola ile giriş.

## ENV
`PORT`, `PUBLIC_BASE_URL`, `ADMIN_PASSWORD`, `CHANNEL_n_NAME|USER|SOURCE_URL` (n=1..5; 6+ yok sayılır), isteğe bağlı `CHANNEL_n_MODE=proxy|ffmpeg`, `STREAM_TOKEN` (doluysa playlist/kanal/segment isteklerinde `?token=` zorunlu, M3U'ya otomatik eklenir), `FFMPEG_PATH`, `FFMPEG_MAX_PROCS` (2), `HLS_SEGMENT_SECONDS` (4), `HLS_LIST_SIZE` (6), `MAX_RSS_MB` (400), `MAX_UPSTREAM_CONNECTIONS` (12), `SEGMENT_CACHE_MB` (24), `CHECK_INTERVAL_SEC` (300, 0=kapalı), `TRUST_PROXY=1`.

## Uç noktalar
`/` panel, `/login`, `/playlist.m3u`, `/channel/1..5.m3u8`, `/api/health` (açık), `/api/status`, `/api/channels` (oturum gerekir; kaynak URL döndürmez).

## Çalışma modları
- **Proxy:** playlist ve alt playlist/segment/anahtar URL'leri `/channel/n/p/<anahtar>` olarak yeniden yazılır; yalnızca playlist içinde görülen URL'ler getirilir (açık proxy yok). Playlist 1 sn, segment 20 sn paylaşımlı önbellek (≤6 MB, toplam `SEGMENT_CACHE_MB`).
- **FFmpeg (`-c copy`):** panelden başlat/durdur; kanal başına tek süreç, `spawn` ile argüman listesi, 3 denemelik artan beklemeli yeniden başlatma, eski segmentler `delete_segments` + dakikalık temizleyici ile silinir. 5 sürecin ücretsiz planda aynı anda çalışacağı **garanti değildir**.

## Kapasite hesabı
Çıkış ≈ izleyici × bitrate. Örn. 4 Mbps ile 10 izleyici ≈ 40 Mbps, 6 Mbps ile 20 izleyici ≈ 120 Mbps. Giriş ≈ kanal × bitrate (segment önbelleği sayesinde izleyici başına artmaz). 5–20 eşzamanlı izleyici **garanti değildir**; Wispbyte bant genişliği/CPU limitine bağlıdır.

## Test
`npm test` — ENV eksikliği, 5 kanal sınırı, M3U, yetkilendirme, CSRF, giriş sınırı, sızıntı, proxy, erişilemeyen kaynak, SSRF, FFmpeg'siz çalışma, FFmpeg/temizlik, yeniden başlatma.

## Sorun giderme
- 503 "kaynak URL tanımlı değil": `CHANNEL_n_SOURCE_URL` boş. 502: kaynak erişilemiyor/geçersiz playlist (Ayarlar → son hatalar).
- `ADMIN_PASSWORD` boşsa panel PAROLASIZ açılır (URL'yi bilen herkes kullanabilir). Parola istiyorsanız doldurun. Açılış logundaki "Görülen ayar adları" satırına bakın. ENV panelden gelmiyorsa proje köküne `.env` dosyası koyabilirsiniz (`KEY=değer` satırları; gerçek sır içerdiği için Git/ZIP'e eklemeyin). Çok deneme: 15 dk bekleyin.
- Cerez/HTTPS: `PUBLIC_BASE_URL` https ise cookie `Secure` olur. Proxy arkasında `TRUST_PROXY=1`.
