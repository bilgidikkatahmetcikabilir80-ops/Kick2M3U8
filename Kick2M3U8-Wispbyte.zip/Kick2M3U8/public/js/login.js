'use strict';
(function () {
  const f = document.getElementById('f');
  const err = document.getElementById('err');
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.hidden = true;
    try {
      const r = await fetch('/api/login', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ password: document.getElementById('pw').value }),
      });
      const j = await r.json().catch(() => ({}));
      if (r.ok) { location.href = '/'; return; }
      err.textContent = j.error || 'Giriş başarısız';
    } catch { err.textContent = 'Sunucuya ulaşılamadı'; }
    err.hidden = false;
  });
})();
