'use strict';
/* Tüm dinamik metin textContent ile yazılır (HTML enjeksiyonu yok). */
window.K2M = (function () {
  let csrf = '';
  const STATUS = {
    unconfigured: ['Yapılandırılmamış', 'idle'], no_source: ['Kaynak URL eksik', 'warn'], configured: ['Yapılandırıldı', 'warn'],
    running: ['Çalışıyor', 'ok'], unreachable: ['Erişilemiyor', 'bad'], error: ['Hata', 'bad'],
  };
  const $ = (s, r = document) => r.querySelector(s);
  function el(tag, cls, txt) { const e = document.createElement(tag); if (cls) e.className = cls; if (txt !== undefined) e.textContent = txt; return e; }

  async function api(path, method = 'GET') {
    const r = await fetch(path, { method, headers: method === 'GET' ? {} : { 'x-csrf-token': csrf } });
    if (r.status === 401) { location.href = '/login'; throw new Error('Oturum yok'); }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(j.error || 'İstek başarısız'); e.data = j; throw e; }
    return j;
  }

  let toastTimer;
  function toast(msg, bad) {
    const t = $('#toast'); t.textContent = msg; t.className = 'toast' + (bad ? ' bad' : ''); t.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 2200);
  }

  async function copy(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
      else {
        const ta = el('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;opacity:0;top:0';
        document.body.appendChild(ta); ta.select();
        const ok = document.execCommand('copy'); ta.remove();
        if (!ok) throw new Error('kopyalanamadı');
      }
      toast('Bağlantı kopyalandı');
    } catch { toast('Kopyalama başarısız; bağlantıyı elle seçin', true); }
  }

  const fmtUp = (s) => { const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return (d ? d + 'g ' : '') + h + 's ' + m + 'dk'; };
  const fmtTime = (iso) => (iso ? new Date(iso).toLocaleTimeString('tr-TR') : '—');
  const modeLabel = (c) => (c.mode === 'ffmpeg' ? 'FFmpeg HLS' : 'Proxy');

  function renderStats(st) {
    const box = $('#stats'); box.replaceChildren();
    const items = [
      ['Toplam kanal kapasitesi', st.channels.capacity], ['Yapılandırılmış kanal', st.channels.configured],
      ['Çalışan yayın', st.channels.running], ['Çalışma süresi', fmtUp(st.system.uptimeSec)],
      ['Bellek (RSS)', st.system.memory.rssMb + ' MB'], ['Son kontrol', fmtTime(st.channels.lastCheck)],
    ];
    for (const [k, v] of items) { const c = el('div', 'card stat'); c.append(el('div', 'v', String(v)), el('div', 'k', k)); box.append(c); }
    const p = $('#srv'); p.textContent = 'Sunucu: çalışıyor'; p.className = 'pill ok';
  }

  function btn(label, fn, cls) { const b = el('button', 'btn ' + (cls || ''), label); b.type = 'button'; b.addEventListener('click', fn); return b; }

  async function act(path, okMsg) {
    try { await api(path, 'POST'); toast(okMsg); } catch (e) { toast(e.message, true); }
    refresh();
  }

  function renderChannels(list) {
    const box = $('#channels'); box.replaceChildren();
    for (const c of list) {
      const card = el('article', 'card');
      const [label, tone] = STATUS[c.status] || STATUS.error;
      const head = el('div', 'ch-head');
      head.append(el('div', 'ch-name', `${c.id}. ${c.name}`), el('span', 'pill ' + tone, label));
      const meta = el('div', 'ch-meta', `Kick: ${c.user || '—'} · Kanal #${c.id} · Mod: ${modeLabel(c)}` + (c.ffmpeg ? (c.ffmpeg.running ? ' (süreç çalışıyor)' : ' (süreç durdu)') : ''));
      card.append(head, meta);
      if (c.lastError) card.append(el('div', 'ch-err', c.lastError));
      if (c.m3u8Url) card.append(el('code', 'url', c.m3u8Url));
      else card.append(el('div', 'muted', 'M3U8 bağlantısı yok: kanal etkin değil.'));
      const a = el('div', 'actions');
      if (c.m3u8Url) {
        a.append(btn('Bağlantıyı kopyala', () => copy(c.m3u8Url), 'primary'));
        a.append(btn('M3U8 aç', () => window.open(c.m3u8Url, '_blank', 'noopener')));
      }
      if (c.hasSource) a.append(btn('Durum kontrolü', () => act(`/api/channels/${c.id}/check`, 'Kontrol tamamlandı')));
      card.append(a); box.append(card);
    }
  }

  let last = { status: null, channels: null };
  async function refresh() {
    try {
      const [st, ch] = await Promise.all([api('/api/status'), api('/api/channels')]);
      last = { status: st, channels: ch.channels };
      renderStats(st); renderChannels(ch.channels);
      document.dispatchEvent(new CustomEvent('k2m:data', { detail: last }));
    } catch (e) {
      const p = $('#srv'); p.textContent = 'Sunucu: erişilemiyor'; p.className = 'pill bad';
    }
  }

  async function init() {
    const s = await fetch('/api/session').then((r) => r.json());
    if (!s.authenticated) { location.href = '/login'; return; }
    csrf = s.csrf;
    $('#btn-logout').addEventListener('click', async () => { try { await api('/api/logout', 'POST'); } catch { /* yok say */ } location.href = '/login'; });
    $('#copy-playlist').addEventListener('click', () => {
      const first = last.channels && last.channels.find((c) => c.m3u8Url);
      if (!first) return toast('Etkin kanal yok', true);
      copy(first.m3u8Url.replace(/\/channel\/\d+\.m3u8/, '/playlist.m3u'));
    });
    await refresh();
    setInterval(() => { if (!document.hidden) refresh(); }, 15000);
  }
  init();
  return { api, el, $, toast, copy, refresh, act, btn, fmtUp, fmtTime, modeLabel, STATUS, get last() { return last; } };
})();
