'use strict';
(function () {
  const { api, el, $, toast, refresh, btn, fmtUp, fmtTime, modeLabel, STATUS } = window.K2M;
  const dlg = $('#settings'), body = $('#settings-body');

  function section(title) { const h = el('h3', '', title); body.append(h); }
  function kv(pairs) {
    const g = el('div', 'kv');
    for (const [k, v] of pairs) g.append(el('div', '', k), el('div', '', String(v)));
    body.append(g);
  }

  async function render() {
    body.replaceChildren(el('p', 'muted', 'Yükleniyor…'));
    let st, ch;
    try { [st, ch] = await Promise.all([api('/api/status'), api('/api/channels')]); }
    catch (e) { body.replaceChildren(el('p', 'error', 'Durum alınamadı: ' + e.message)); return; }
    body.replaceChildren();
    const s = st.system;
    section('Sunucu');
    kv([
      ['Uygulama çalışıyor mu?', 'Evet'], ['Çalışma süresi', fmtUp(s.uptimeSec)], ['Node.js', s.node],
      ['Bellek (RSS / limit)', `${s.memory.rssMb} MB / ${s.memory.limitMb} MB`], ['Heap kullanımı', s.memory.heapUsedMb + ' MB'],
      ['CPU kullanımı', s.cpu], ['Etkin kanal', `${st.channels.configured} / ${st.channels.capacity}`],
      ['FFmpeg', s.ffmpeg.available ? 'Mevcut (' + s.ffmpeg.version + ')' : 'Bulunamadı (proxy modu çalışır)'],
      ['FFmpeg süreci', `${s.ffmpeg.processes} / ${s.ffmpeg.maxProcs}`],
      ['Yönetici parolası', s.adminConfigured ? 'Ayarlı' : 'Yok (panel parolasız açık)'],
      ['Stream token', s.streamTokenEnabled ? 'Etkin' : 'Kapalı (bağlantıyı bilen izleyebilir)'],
      ['PUBLIC_BASE_URL', s.publicBaseConfigured ? 'Ayarlı' : 'Ayarlı değil (istek adresi kullanılır)'],
    ]);
    if (s.ignoredChannelNumbers.length) body.append(el('div', 'note', 'Uyarı: 5 kanal sınırı nedeniyle yok sayılan kanal numaraları: ' + s.ignoredChannelNumbers.join(', ')));
    body.append(el('div', 'note', 'Ücretsiz planda 5 FFmpeg sürecini aynı anda çalıştırmak garanti edilmez; limitler aşılırsa süreçler başlatılmaz veya sistem tarafından sonlandırılır.'));

    section('Kanallar');
    for (const c of ch.channels) {
      const row = el('div', 'row');
      const [label, tone] = STATUS[c.status] || STATUS.error;
      const h = el('div', 'ch-head'); h.append(el('strong', '', `${c.id}. ${c.name}`), el('span', 'pill ' + tone, label));
      row.append(h, el('div', 'ch-meta', `Mod: ${modeLabel(c)} · Son kontrol: ${fmtTime(c.lastCheck)} · Hata: ${c.errors} · Yeniden deneme: ${c.retries}`));
      if (c.lastError) row.append(el('div', 'ch-err', c.lastError));
      const a = el('div', 'actions');
      const run = (path, msg) => async () => { try { await api(path, 'POST'); toast(msg); } catch (e) { toast(e.message, true); } await render(); refresh(); };
      if (c.hasSource) {
        a.append(btn('Bağlantıyı test et', run(`/api/channels/${c.id}/check`, 'Test tamamlandı')));
        a.append(btn('Yeniden bağlan', run(`/api/channels/${c.id}/reconnect`, 'Yeniden bağlantı denendi')));
        if (c.mode === 'ffmpeg') {
          a.append(btn('FFmpeg başlat', run(`/api/channels/${c.id}/ffmpeg/start`, 'FFmpeg başlatıldı'), 'primary'));
          a.append(btn('FFmpeg durdur', run(`/api/channels/${c.id}/ffmpeg/stop`, 'FFmpeg durduruldu')));
        }
      } else a.append(el('span', 'muted', c.status === 'unconfigured' ? 'Kanal ENV ile tanımlanmamış.' : 'Kaynak URL ENV içinde tanımlanmalı.'));
      row.append(a); body.append(row);
    }

    section('M3U playlist testi');
    const out = el('div', 'muted', 'Henüz çalıştırılmadı.');
    body.append(btn('Playlist endpoint testi', async () => {
      try {
        const r = await api('/api/playlist-test');
        out.textContent = r.valid ? `Geçerli: ${r.entries} kanal, ${r.bytes} bayt.` : 'Playlist biçimi geçersiz!';
      } catch (e) { out.textContent = 'Hata: ' + e.message; }
    }), out);

    section('Son hatalar ve olaylar');
    const ul = el('ul', 'events');
    if (!st.events.length) ul.append(el('li', 'muted', 'Kayıt yok.'));
    for (const ev of st.events.slice(0, 15)) ul.append(el('li', '', `${fmtTime(ev.t)} · Kanal ${ev.channel} · ${ev.message}`));
    body.append(ul);

    section('Yeniden başlatma ve ENV');
    body.append(el('div', 'note', st.notes.restart), el('div', 'note', st.notes.env));
    body.append(btn('Durumu yenile', () => { render(); refresh(); }));
  }

  $('#btn-settings').addEventListener('click', () => { dlg.showModal(); render(); });
  $('#close-settings').addEventListener('click', () => dlg.close());
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
})();
