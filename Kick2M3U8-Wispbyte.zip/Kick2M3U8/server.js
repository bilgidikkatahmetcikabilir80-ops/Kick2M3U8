'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const config = require('./src/config');
const { createAuth } = require('./src/auth');
const { createChannels } = require('./src/channels');
const { createProxy, HttpError } = require('./src/proxy');
const { createFfmpeg } = require('./src/ffmpeg');
const { systemStatus, detectFfmpeg } = require('./src/health');
const { scrub } = require('./src/net');

const PUBLIC = path.join(__dirname, 'public');
const STATIC_MIME = { '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

function createApp(env = process.env) {
  const cfg = config.load(env);
  const startedAt = Date.now();
  const auth = createAuth(cfg);
  const chs = createChannels(cfg);
  const proxy = createProxy(cfg, chs.hooks);
  const ffm = createFfmpeg(cfg, chs.hooks);
  chs.attach(proxy, ffm);

  const secHeaders = {
    'x-content-type-options': 'nosniff', 'x-frame-options': 'DENY', 'referrer-policy': 'no-referrer',
    'content-security-policy': "default-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  };

  const safeEq = (a, b) => { const x = crypto.createHash('sha256').update(String(a)).digest(); const y = crypto.createHash('sha256').update(String(b)).digest(); return crypto.timingSafeEqual(x, y); };

  function baseUrl(req) {
    if (cfg.publicBaseUrl) return cfg.publicBaseUrl;
    const host = String(req.headers.host || '');
    const proto = req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
    return /^[A-Za-z0-9.\-:[\]]+$/.test(host) ? `${proto}://${host}` : `http://localhost:${cfg.port}`;
  }
  const tq = () => (cfg.streamToken ? `?token=${encodeURIComponent(cfg.streamToken)}` : '');

  function json(res, status, obj, extra = {}) {
    const body = JSON.stringify(obj);
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...extra });
    res.end(body);
  }
  function text(res, status, body, extra = {}) {
    res.writeHead(status, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store', ...extra });
    res.end(body);
  }
  function readJson(req) {
    return new Promise((resolve, reject) => {
      let n = 0; const chunks = [];
      req.on('data', (c) => { n += c.length; if (n > 4096) { reject(new HttpError(413, 'İstek çok büyük')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(new HttpError(400, 'Geçersiz JSON')); } });
      req.on('error', reject);
    });
  }
  function streamAllowed(req, u) {
    if (!cfg.streamToken) return true;
    const t = u.searchParams.get('token');
    return (t && safeEq(t, cfg.streamToken)) || !!auth.getSession(req);
  }
  function fail(res, e) {
    if (res.headersSent) { res.destroy(); return; }
    const status = e instanceof HttpError ? e.status : 502;
    const msg = e instanceof HttpError ? e.message : `Kaynağa erişilemedi: ${scrub(e && e.message)}`;
    text(res, status, msg, status === 503 ? { 'retry-after': '3' } : {});
  }

  function buildM3u(req) {
    const base = baseUrl(req);
    const lines = ['#EXTM3U'];
    for (const ch of cfg.channels) {
      if (!chs.isActive(ch)) continue;
      lines.push(`#EXTINF:-1,${chs.displayName(ch).replace(/[\r\n]+/g, ' ')}`);
      lines.push(`${base}/channel/${ch.id}.m3u8${tq()}`);
    }
    return lines.join('\n') + '\n';
  }

  async function serveChannel(req, res, id) {
    const ch = chs.get(id);
    if (!ch) return text(res, 404, 'Kanal bulunamadı (en fazla 5 kanal desteklenir)');
    if (!chs.isActive(ch)) return text(res, 503, 'Kanal yapılandırılmamış veya kaynak URL tanımlı değil');
    try {
      if (ch.mode === 'ffmpeg') {
        if (!ffm.isRunning(id)) return text(res, 503, 'FFmpeg süreci çalışmıyor; panelden başlatın', { 'retry-after': '5' });
        let raw;
        try { raw = fs.readFileSync(path.join(ffm.dirOf(id), 'index.m3u8'), 'utf8'); }
        catch { return text(res, 503, 'FFmpeg çıktısı henüz hazır değil', { 'retry-after': '3' }); }
        const out = raw.split(/\r?\n/).map((l) => (/^seg_\d{5}\.ts$/.test(l.trim()) ? `/channel/${id}/f/${l.trim()}${tq()}` : l)).join('\n');
        res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl', 'cache-control': 'no-cache' });
        return res.end(out);
      }
      await proxy.servePlaylist(req, res, ch, await chs.source(ch), tq());
    } catch (e) { chs.hooks.onFail(id, e); fail(res, e); }
  }

  async function serveSub(req, res, id, key) {
    const ch = chs.get(id);
    if (!ch || !chs.isActive(ch) || ch.mode !== 'proxy') return text(res, 404, 'Bulunamadı');
    try { await proxy.serveSub(req, res, ch, key, tq()); }
    catch (e) { if (!(e instanceof HttpError && e.status === 404)) chs.hooks.onFail(id, e); fail(res, e); }
  }

  function serveFfSeg(req, res, id, name) {
    const ch = chs.get(id);
    if (!ch || !ffm.isRunning(id)) return text(res, 404, 'Bulunamadı');
    const fp = path.join(ffm.dirOf(id), name);
    fs.stat(fp, (err, st) => {
      if (err || !st.isFile()) return text(res, 404, 'Segment bulunamadı');
      res.writeHead(200, { 'content-type': 'video/mp2t', 'content-length': st.size, 'cache-control': 'public, max-age=10' });
      fs.createReadStream(fp).on('error', () => res.destroy()).pipe(res);
    });
  }

  function serveFile(res, file, type) {
    fs.readFile(file, (err, buf) => {
      if (err) return text(res, 404, 'Bulunamadı');
      res.writeHead(200, { 'content-type': type, 'cache-control': 'no-cache' });
      res.end(buf);
    });
  }

  async function api(req, res, u) {
    const p = u.pathname, method = req.method;
    if (p === '/api/health' && method === 'GET') return json(res, 200, { ok: true });
    if (p === '/api/session' && method === 'GET') {
      const s = auth.getSession(req);
      return json(res, 200, { authenticated: !!s, csrf: s ? s.csrf : null, adminConfigured: !!cfg.adminPassword });
    }
    if (p === '/api/login' && method === 'POST') {
      const origin = req.headers.origin;
      if (origin) { try { if (new URL(origin).host !== req.headers.host) return json(res, 403, { error: 'Geçersiz kaynak' }); } catch { return json(res, 403, { error: 'Geçersiz kaynak' }); } }
      const body = await readJson(req);
      const r = auth.login(req, typeof body.password === 'string' ? body.password : '');
      if (!r.ok) return json(res, r.status, { error: r.error });
      return json(res, 200, { ok: true, csrf: r.csrf }, { 'set-cookie': r.cookie });
    }
    const session = auth.getSession(req);
    if (!session) return json(res, 401, { error: 'Yetkisiz. Lütfen giriş yapın.' });
    const mutating = method !== 'GET' && method !== 'HEAD';
    if (mutating && !auth.csrfOk(req, session)) return json(res, 403, { error: 'CSRF doğrulaması başarısız' });

    if (p === '/api/logout' && method === 'POST') return json(res, 200, { ok: true }, { 'set-cookie': auth.logout(req) });
    if (p === '/api/channels' && method === 'GET') return json(res, 200, { channels: chs.list(baseUrl(req), tq()), capacity: cfg.maxChannels });
    if (p === '/api/status' && method === 'GET') {
      const c = chs.counts();
      return json(res, 200, {
        system: systemStatus(cfg, startedAt, ffm.count()),
        channels: { capacity: cfg.maxChannels, configured: c.configured, running: c.running, lastCheck: chs.lastCheckAny() },
        proxy: proxy.stats(), events: chs.events(),
        notes: {
          restart: 'Uygulamayı yeniden başlatmak için Wispbyte panelindeki Restart/Stop-Start düğmesini kullanın. Bu panel sunucuyu yeniden başlatamaz.',
          env: 'Ortam değişkenleri yalnızca Wispbyte panelinden değiştirilir; değişiklikten sonra uygulamayı yeniden başlatın.',
        },
      });
    }
    if (p === '/api/playlist-test' && method === 'GET') {
      const body = buildM3u(req);
      const lines = body.trim().split('\n');
      let valid = lines[0] === '#EXTM3U';
      let entries = 0;
      for (let i = 1; i < lines.length; i += 2) { if (!lines[i].startsWith('#EXTINF:') || !/^https?:\/\//.test(lines[i + 1] || '')) valid = false; else entries++; }
      return json(res, 200, { valid, entries, bytes: Buffer.byteLength(body) });
    }
    let m = /^\/api\/channels\/([1-9]\d*)\/(check|reconnect|ffmpeg\/start|ffmpeg\/stop)$/.exec(p);
    if (m && method === 'POST') {
      const id = Number(m[1]); const ch = chs.get(id);
      if (!ch) return json(res, 404, { error: 'Kanal bulunamadı (en fazla 5 kanal)' });
      try {
        if (m[2] === 'check') await chs.check(id);
        else if (m[2] === 'reconnect') await chs.reconnect(id);
        else if (m[2] === 'ffmpeg/start') { await ffm.start({ ...ch, sourceUrl: await chs.source(ch) }); chs.log(id, 'ffmpeg', 'FFmpeg başlatıldı'); }
        else { ffm.stop(id); chs.log(id, 'ffmpeg', 'FFmpeg durduruldu'); }
      } catch (e) { return json(res, 409, { error: scrub(e.message), channel: chs.view(ch, baseUrl(req), tq()) }); }
      return json(res, 200, { ok: true, channel: chs.view(ch, baseUrl(req), tq()) });
    }
    return json(res, 404, { error: 'Bulunamadı' });
  }

  async function handler(req, res) {
    for (const [k, v] of Object.entries(secHeaders)) res.setHeader(k, v);
    const u = new URL(req.url, 'http://localhost');
    const p = u.pathname;
    if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'POST') return text(res, 405, 'Yöntem desteklenmiyor');
    let m;
    if (p.startsWith('/api/')) return api(req, res, u);
    if (req.method === 'POST') return text(res, 404, 'Bulunamadı');

    if (p === '/playlist.m3u') {
      if (!streamAllowed(req, u)) return text(res, 401, 'Geçersiz veya eksik token');
      res.writeHead(200, { 'content-type': 'audio/x-mpegurl; charset=utf-8', 'cache-control': 'no-cache' });
      return res.end(buildM3u(req));
    }
    if ((m = /^\/channel\/(\d+)\.m3u8$/.exec(p))) {
      if (!streamAllowed(req, u)) return text(res, 401, 'Geçersiz veya eksik token');
      return serveChannel(req, res, Number(m[1]));
    }
    if ((m = /^\/channel\/(\d+)\/p\/([A-Za-z0-9_-]{16})(\.[a-z0-9]+)?$/.exec(p))) {
      if (!streamAllowed(req, u)) return text(res, 401, 'Geçersiz veya eksik token');
      return serveSub(req, res, Number(m[1]), m[2]);
    }
    if ((m = /^\/channel\/(\d+)\/f\/(seg_\d{5}\.ts)$/.exec(p))) {
      if (!streamAllowed(req, u)) return text(res, 401, 'Geçersiz veya eksik token');
      return serveFfSeg(req, res, Number(m[1]), m[2]);
    }
    if (p === '/login') {
      if (auth.getSession(req)) { res.writeHead(302, { location: '/' }); return res.end(); }
      return serveFile(res, path.join(PUBLIC, 'login.html'), 'text/html; charset=utf-8');
    }
    if (p === '/') {
      if (!auth.getSession(req)) { res.writeHead(302, { location: '/login' }); return res.end(); }
      return serveFile(res, path.join(PUBLIC, 'index.html'), 'text/html; charset=utf-8');
    }
    if ((m = /^\/(css|js)\/([A-Za-z0-9_.-]+)$/.exec(p))) {
      const type = STATIC_MIME[path.extname(m[2])];
      if (type) return serveFile(res, path.join(PUBLIC, m[1], m[2]), type);
    }
    return text(res, 404, 'Bulunamadı');
  }

  const server = http.createServer((req, res) => {
    Promise.resolve(handler(req, res)).catch((e) => {
      if (e instanceof HttpError) return json(res, e.status, { error: e.message });
      console.error('[hata]', scrub(e && e.message));
      if (!res.headersSent) text(res, 500, 'Sunucu hatası'); else res.destroy();
    });
  });
  server.headersTimeout = 15000;
  server.requestTimeout = 0;
  server.keepAliveTimeout = 5000;

  function listen(port = cfg.port, host = cfg.host) {
    return new Promise((resolve) => {
      server.listen(port, host, () => {
        ffm.cleanupAll();
        ffm.ensureJanitor();
        chs.startScheduler();
        resolve(server.address());
      });
    });
  }
  function shutdown() {
    chs.stopScheduler();
    ffm.cleanupAll();
    return new Promise((r) => { server.close(() => r()); server.closeAllConnections && server.closeAllConnections(); });
  }
  return { cfg, server, listen, shutdown, ffm, chs, proxy };
}

module.exports = { createApp };

function loadDotEnv(file) {
  // Yedek yöntem: .env dosyası varsa, tanımlı olmayan değişkenleri doldurur (mevcut ENV ezilmez).
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); } catch { return 0; }
  let n = 0;
  for (const line of raw.split(/\r?\n/)) {
    const m = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);
    if (!m || line.trim().startsWith('#')) continue;
    let v = m[2];
    if (/^(".*"|'.*')$/.test(v)) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined || process.env[m[1]] === '') { process.env[m[1]] = v; n++; }
  }
  return n;
}

if (require.main === module) {
  const dotenvCount = loadDotEnv(path.join(__dirname, '.env'));
  const app = createApp();
  process.on('uncaughtException', (e) => console.error('[uncaughtException]', scrub(e && e.message)));
  process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', scrub(e && e.message)));
  app.listen().then((addr) => {
    const ff = detectFfmpeg(app.cfg.ffmpegPath);
    console.log(`Kick2M3U8 ${addr.address}:${addr.port} üzerinde dinliyor | Node ${process.version} | FFmpeg: ${ff.available ? ff.version : 'yok (proxy modu)'}`);
    const seen = Object.keys(process.env).filter((k) => /^(ADMIN_PASSWORD|PUBLIC_BASE_URL|STREAM_TOKEN|CHANNEL_\d+_(NAME|USER|SOURCE_URL|MODE))$/.test(k) && process.env[k] !== '');
    console.log(`Görülen ayar adları (değerler gösterilmez): ${seen.join(', ') || 'hiçbiri'}${dotenvCount ? ` | .env'den ${dotenvCount} değer okundu` : ''}`);
    if (!app.cfg.adminPassword) console.warn('UYARI: ADMIN_PASSWORD boş; yönetim paneli PAROLASIZ açık. URL’yi bilen herkes paneli kullanabilir.');
    if (app.cfg.ignoredChannels.length) console.warn(`UYARI: 5 kanal sınırı nedeniyle yok sayılan kanal numaraları: ${app.cfg.ignoredChannels.join(', ')}`);
  });
  const quit = () => { setTimeout(() => process.exit(0), 5000).unref(); app.shutdown().then(() => process.exit(0)); };
  process.on('SIGTERM', quit);
  process.on('SIGINT', quit);
}
