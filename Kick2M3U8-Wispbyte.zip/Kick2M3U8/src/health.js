'use strict';
const { spawnSync } = require('node:child_process');

let ffCache = null;

/** FFmpeg varlığını bir kez denetler (sonuç önbelleğe alınır). */
function detectFfmpeg(ffmpegPath) {
  if (ffCache && ffCache.path === ffmpegPath) return ffCache;
  let available = false, version = null;
  try {
    const r = spawnSync(ffmpegPath, ['-version'], { timeout: 5000, encoding: 'utf8' });
    if (r.status === 0 && r.stdout) {
      available = true;
      version = (r.stdout.split('\n')[0].match(/version\s+(\S+)/) || [])[1] || 'bilinmiyor';
    }
  } catch { /* yok */ }
  ffCache = { path: ffmpegPath, available, version };
  return ffCache;
}

function mb(n) { return Math.round((n / 1048576) * 10) / 10; }

function systemStatus(cfg, startedAt, ffmpegProcCount) {
  const m = process.memoryUsage();
  const ff = detectFfmpeg(cfg.ffmpegPath);
  return {
    ok: true,
    time: new Date().toISOString(),
    uptimeSec: Math.round(process.uptime()),
    startedAt: new Date(startedAt).toISOString(),
    node: process.version,
    memory: { rssMb: mb(m.rss), heapUsedMb: mb(m.heapUsed), limitMb: cfg.maxRssMb },
    cpu: 'Desteklenmiyor',
    ffmpeg: { available: ff.available, version: ff.version, processes: ffmpegProcCount, maxProcs: cfg.ffmpegMaxProcs },
    capacity: cfg.maxChannels,
    ignoredChannelNumbers: cfg.ignoredChannels,
    adminConfigured: !!cfg.adminPassword,
    streamTokenEnabled: !!cfg.streamToken,
    publicBaseConfigured: !!cfg.publicBaseUrl,
  };
}

module.exports = { detectFfmpeg, systemStatus };
