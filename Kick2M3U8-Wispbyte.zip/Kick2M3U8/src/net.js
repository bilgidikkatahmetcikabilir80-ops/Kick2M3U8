'use strict';
const dns = require('node:dns').promises;
const net = require('node:net');

function isPrivateIPv4(ip) {
  const p = ip.split('.').map(Number);
  const [a, b] = p;
  return (
    a === 0 || a === 10 || a === 127 ||
    (a === 100 && b >= 64 && b <= 127) ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 0 && p[2] === 0) ||
    (a === 192 && b === 168) ||
    (a === 198 && (b === 18 || b === 19)) ||
    a >= 224
  );
}

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) return isPrivateIPv4(ip);
  if (net.isIPv6(ip)) {
    const l = ip.toLowerCase();
    if (l === '::' || l === '::1') return true;
    let m = l.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (m) return isPrivateIPv4(m[1]);
    m = l.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
    if (m) {
      const hi = parseInt(m[1], 16), lo = parseInt(m[2], 16);
      return isPrivateIPv4(`${hi >> 8}.${hi & 255}.${lo >> 8}.${lo & 255}`);
    }
    return /^f[cd]/.test(l) || /^fe[89ab]/.test(l) || l.startsWith('ff');
  }
  return true;
}

/** Yalnızca genel (public) http/https adreslerine izin verir. SSRF koruması. */
async function assertSafeUrl(urlStr, { allowPrivate = false } = {}) {
  const u = new URL(urlStr);
  if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('Yalnızca http/https desteklenir');
  if (u.username || u.password) throw new Error('URL kullanıcı bilgisi içeremez');
  if (allowPrivate) return u;
  const host = u.hostname.replace(/^\[|\]$/g, '');
  if (net.isIP(host)) {
    if (isPrivateIp(host)) throw new Error('Özel ağ adreslerine erişim engellendi');
    return u;
  }
  const h = host.toLowerCase();
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal')) {
    throw new Error('Özel ağ adreslerine erişim engellendi');
  }
  const addrs = await dns.lookup(host, { all: true });
  if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) {
    throw new Error('Özel ağ adreslerine erişim engellendi');
  }
  return u;
}

/** Hata mesajlarından URL ve olası sırları temizler. */
function scrub(msg) {
  return String(msg || '').replace(/https?:\/\/\S+/gi, '[url]').replace(/token=[^\s&]+/gi, 'token=***').slice(0, 200);
}

module.exports = { assertSafeUrl, isPrivateIp, scrub };
