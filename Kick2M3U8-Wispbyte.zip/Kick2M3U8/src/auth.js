'use strict';
const crypto = require('node:crypto');

const COOKIE = 'k2m_sid';
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const MAX_SESSIONS = 50;
const MAX_FAILS = 5;
const FAIL_WINDOW_MS = 15 * 60 * 1000;

function sha(s) { return crypto.createHash('sha256').update(String(s)).digest(); }

function createAuth(cfg) {
  const sessions = new Map();
  const fails = new Map();

  function parseCookies(h) {
    const out = {};
    for (const part of String(h || '').split(';')) {
      const i = part.indexOf('=');
      if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
    }
    return out;
  }

  function clientIp(req) {
    if (cfg.trustProxy) {
      const xf = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
      if (xf) return xf;
    }
    return req.socket.remoteAddress || 'unknown';
  }

  function isSecure(req) {
    return cfg.publicBaseUrl.startsWith('https://') || req.headers['x-forwarded-proto'] === 'https' || !!req.socket.encrypted;
  }

  function prune() {
    const now = Date.now();
    for (const [k, s] of sessions) if (s.exp < now) sessions.delete(k);
    for (const [k, f] of fails) if (now - f.first > FAIL_WINDOW_MS) fails.delete(k);
    while (sessions.size > MAX_SESSIONS) sessions.delete(sessions.keys().next().value);
  }

  const open = !cfg.adminPassword; // parola yoksa panel doğrudan açılır
  const openSession = { csrf: crypto.randomBytes(24).toString('hex'), exp: Infinity };

  function getSession(req) {
    if (open) return openSession;
    const sid = parseCookies(req.headers.cookie)[COOKIE];
    if (!sid) return null;
    const s = sessions.get(sid);
    if (!s || s.exp < Date.now()) { sessions.delete(sid); return null; }
    return s;
  }

  /** @returns {{ok:boolean,status?:number,error?:string,cookie?:string,csrf?:string}} */
  function login(req, password) {
    prune();
    if (open) return { ok: true, cookie: `${COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`, csrf: openSession.csrf };
    const ip = clientIp(req);
    const f = fails.get(ip);
    if (f && f.count >= MAX_FAILS && Date.now() - f.first < FAIL_WINDOW_MS) {
      return { ok: false, status: 429, error: 'Çok fazla başarısız deneme. Daha sonra tekrar deneyin.' };
    }
    const good = crypto.timingSafeEqual(sha(password), sha(cfg.adminPassword));
    if (!good) {
      const cur = f && Date.now() - f.first < FAIL_WINDOW_MS ? f : { count: 0, first: Date.now() };
      cur.count++;
      fails.set(ip, cur);
      return { ok: false, status: 401, error: 'Parola hatalı' };
    }
    fails.delete(ip);
    const sid = crypto.randomBytes(32).toString('hex');
    const csrf = crypto.randomBytes(24).toString('hex');
    sessions.set(sid, { csrf, exp: Date.now() + SESSION_TTL_MS });
    const cookie = `${COOKIE}=${sid}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_TTL_MS / 1000}${isSecure(req) ? '; Secure' : ''}`;
    return { ok: true, cookie, csrf };
  }

  function logout(req) {
    const sid = parseCookies(req.headers.cookie)[COOKIE];
    if (sid) sessions.delete(sid);
    return `${COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`;
  }

  /** Durum değiştiren istekler için CSRF kontrolü: Origin + özel başlık. */
  function csrfOk(req, session) {
    const origin = req.headers.origin;
    if (origin) {
      try { if (new URL(origin).host !== req.headers.host) return false; } catch { return false; }
    }
    const tok = String(req.headers['x-csrf-token'] || '');
    const a = sha(tok), b = sha(session.csrf);
    return crypto.timingSafeEqual(a, b);
  }

  return { getSession, login, logout, csrfOk, clientIp };
}

module.exports = { createAuth };
