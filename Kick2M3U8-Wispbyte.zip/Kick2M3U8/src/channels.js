'use strict';
const { scrub } = require('./net');

/** Kanal durumlarını, olay günlüğünü ve kontrolleri yönetir. Kaynak URL'leri asla dışarı verilmez. */
function createChannels(cfg) {
  const state = new Map();
  const events = [];
  let proxy = null, ffm = null, timer = null;

  for (const ch of cfg.channels) state.set(ch.id, { check: null, lastCheck: null, lastOk: null, lastError: '', retries: 0, errors: 0 });

  function log(id, kind, message) {
    events.push({ t: new Date().toISOString(), channel: id, kind, message: scrub(message) });
    while (events.length > 40) events.shift();
  }
  const get = (id) => cfg.channels[id - 1];
  const isActive = (ch) => !!ch && (!!ch.sourceUrl || !!ch.resolve);
  const resolved = new Map();
  async function source(ch) {
    if (ch.sourceUrl) return ch.sourceUrl;
    const c = resolved.get(ch.id);
    if (c && Date.now() - c.t < 240000) return c.url;
    const url = await proxy.resolveKick(ch.user);
    resolved.set(ch.id, { url, t: Date.now() });
    return url;
  }
  const displayName = (ch) => ch.name || ch.user || `Kanal ${ch.id}`;

  function statusOf(ch) {
    const s = state.get(ch.id);
    if (!ch.name && !ch.user && !ch.sourceUrl && !ch.sourceError) return 'unconfigured';
    if (ch.sourceError) return 'error';
    if (!isActive(ch)) return 'no_source';
    if (ch.mode === 'ffmpeg') {
      if (ffm && ffm.isRunning(ch.id)) return 'running';
      return s.check === 'unreachable' ? 'unreachable' : s.check === 'error' ? 'error' : 'configured';
    }
    return s.check === 'ok' ? 'running' : s.check === 'unreachable' ? 'unreachable' : s.check === 'error' ? 'error' : 'configured';
  }

  function view(ch, base, tq) {
    const s = state.get(ch.id);
    return {
      id: ch.id, name: displayName(ch), user: ch.user, mode: ch.mode,
      status: statusOf(ch), active: isActive(ch), hasSource: isActive(ch),
      lastCheck: s.lastCheck, lastOk: s.lastOk,
      lastError: ch.sourceError || s.lastError || '', errors: s.errors, retries: s.retries,
      ffmpeg: ch.mode === 'ffmpeg' && ffm ? ffm.info(ch.id) : null,
      m3u8Url: isActive(ch) ? `${base}/channel/${ch.id}.m3u8${tq}` : null,
    };
  }

  const list = (base, tq) => cfg.channels.map((c) => view(c, base, tq));
  const counts = () => {
    let configured = 0, running = 0;
    for (const c of cfg.channels) {
      if (isActive(c)) configured++;
      if (statusOf(c) === 'running') running++;
    }
    return { configured, running };
  };
  const lastCheckAny = () => {
    let best = null;
    for (const s of state.values()) if (s.lastCheck && (!best || s.lastCheck > best)) best = s.lastCheck;
    return best;
  };

  function markOk(id) { const s = state.get(id); s.check = 'ok'; s.lastOk = new Date().toISOString(); s.lastError = ''; }
  function markFail(id, err) {
    const s = state.get(id);
    const msg = err && err.status === 502 && /geçerli/.test(err.message) ? 'error' : 'unreachable';
    s.check = msg; s.errors++;
    s.lastError = err && err.message ? scrub(err.message) : 'Bilinmeyen hata';
    log(id, 'error', s.lastError);
  }

  async function check(id) {
    const ch = get(id);
    const s = state.get(id);
    if (!isActive(ch)) { s.lastError = ch && ch.sourceError ? ch.sourceError : 'Kaynak URL tanımlı değil'; return; }
    s.lastCheck = new Date().toISOString();
    try { await proxy.probe(await source(ch)); markOk(id); log(id, 'check', 'Kaynak kontrolü başarılı'); }
    catch (e) { markFail(id, e); }
  }

  async function reconnect(id) {
    const ch = get(id); const s = state.get(id);
    s.retries++;
    log(id, 'retry', `Yeniden bağlantı denemesi #${s.retries}`);
    if (ch.mode === 'ffmpeg') { ffm.stop(id); await new Promise((r) => setTimeout(r, 600)); await ffm.start({ ...ch, sourceUrl: await source(ch) }); return; }
    await check(id);
  }

  async function checkAll() { for (const c of cfg.channels) if (isActive(c)) await check(c.id); }
  function startScheduler() {
    if (!cfg.checkIntervalSec || timer) return;
    timer = setInterval(() => { checkAll().catch(() => {}); }, Math.max(60, cfg.checkIntervalSec) * 1000);
    timer.unref();
  }
  function stopScheduler() { if (timer) clearInterval(timer); timer = null; }

  const hooks = {
    onOk: (id) => markOk(id),
    onFail: (id, e) => markFail(id, e),
    onError: (id, msg) => { const s = state.get(id); s.lastError = scrub(msg); s.errors++; log(id, 'error', msg); },
    onRetry: (id, n, wait) => { const s = state.get(id); s.retries++; log(id, 'retry', `FFmpeg yeniden başlatma ${n}/3, ${Math.round(wait / 1000)} sn sonra`); },
    onGiveUp: (id) => { const s = state.get(id); s.check = 'error'; log(id, 'error', 'FFmpeg yeniden başlatma denemeleri tükendi'); },
  };

  return {
    hooks, get, isActive, source, displayName, list, view, counts, lastCheckAny, check, checkAll, reconnect,
    events: () => events.slice().reverse(), log, startScheduler, stopScheduler,
    attach: (p, f) => { proxy = p; ffm = f; },
  };
}

module.exports = { createChannels };
