'use strict';
const crypto = require('node:crypto');
const { Readable, pipeline } = require('node:stream');
const { assertSafeUrl } = require('./net');

const UA = 'Mozilla/5.0 (compatible; Kick2M3U8/1.0)';
const EXT_RE = /\.(m3u8|ts|m4s|mp4|aac|mp3|vtt|webvtt|key|cmfv|cmfa)$/i;
const MIME = {
  m3u8: 'application/vnd.apple.mpegurl', ts: 'video/mp2t', m4s: 'video/iso.segment', mp4: 'video/mp4',
  cmfv: 'video/mp4', cmfa: 'audio/mp4', aac: 'audio/aac', mp3: 'audio/mpeg', vtt: 'text/vtt', webvtt: 'text/vtt',
  key: 'application/octet-stream',
};

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function extOf(u) {
  try { const m = EXT_RE.exec(new URL(u).pathname); return m ? m[1].toLowerCase() : ''; } catch { return ''; }
}

/**
 * Yalnızca yapılandırılmış kaynak ve o kaynağın playlistlerinde geçen URL'leri sunar.
 * Serbest URL kabul edilmez (açık proxy yoktur).
 */
function createProxy(cfg, hooks = {}) {
  let active = 0;
  const registry = new Map();      // kanalId -> Map(key -> url)
  const textCache = new Map();     // url -> {t, p}
  const segCache = new Map();      // url -> {t, buf, type}
  const inflight = new Map();      // url -> Promise
  const noBuf = new Set();
  let segBytes = 0;

  function register(chId, url) {
    let m = registry.get(chId);
    if (!m) { m = new Map(); registry.set(chId, m); }
    const key = crypto.createHash('sha1').update(url).digest('base64url').slice(0, 16);
    m.delete(key); m.set(key, url);
    while (m.size > 1500) m.delete(m.keys().next().value);
    return key;
  }
  const lookup = (chId, key) => (registry.get(chId) || new Map()).get(key);

  async function fetchUp(url, { headers = {}, timeoutMs = cfg.upstreamTimeoutMs, signal } = {}) {
    if (active >= cfg.maxUpstream) throw new HttpError(503, 'Çok fazla eşzamanlı kaynak bağlantısı');
    active++;
    let released = false;
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(new Error('Kaynak zaman aşımı')), timeoutMs);
    const release = () => { clearTimeout(timer); if (!released) { released = true; active--; } };
    if (signal) { if (signal.aborted) ac.abort(); else signal.addEventListener('abort', () => ac.abort(), { once: true }); }
    try {
      let cur = url;
      for (let hop = 0; hop <= 3; hop++) {
        await assertSafeUrl(cur, { allowPrivate: cfg.allowPrivate });
        const r = await fetch(cur, { headers: { 'user-agent': UA, ...headers }, redirect: 'manual', signal: ac.signal });
        const loc = r.headers.get('location');
        if (r.status >= 300 && r.status < 400 && loc) {
          cur = new URL(loc, cur).href;
          try { await r.body?.cancel(); } catch { /* yok say */ }
          continue;
        }
        return { res: r, url: cur, release };
      }
      throw new Error('Çok fazla yönlendirme');
    } catch (e) {
      release();
      throw e;
    }
  }

  async function readLimited(res, max) {
    const chunks = []; let n = 0;
    for await (const c of res.body) {
      n += c.length;
      if (n > max) throw new Error('Yanıt çok büyük');
      chunks.push(c);
    }
    return Buffer.concat(chunks);
  }

  async function fetchText(url) {
    const f = await fetchUp(url);
    try {
      if (!f.res.ok) throw new HttpError(502, `Kaynak HTTP ${f.res.status} döndürdü`);
      const buf = await readLimited(f.res, cfg.maxPlaylistBytes);
      return { text: buf.toString('utf8'), url: f.url };
    } finally { f.release(); }
  }

  /** Aynı playlist için eşzamanlı izleyicilerin tek kaynak isteğini paylaşması (1 sn). */
  function cachedText(url) {
    const now = Date.now();
    const c = textCache.get(url);
    if (c && now - c.t < 1000) return c.p;
    const p = fetchText(url);
    textCache.set(url, { t: now, p });
    p.catch(() => { if (textCache.get(url)?.p === p) textCache.delete(url); });
    if (textCache.size > 50) textCache.delete(textCache.keys().next().value);
    return p;
  }

  function rewrite(text, baseUrl, chId, tq) {
    const conv = (ref) => {
      let abs;
      try { abs = new URL(ref, baseUrl).href; } catch { return ref; }
      if (!/^https?:/i.test(abs)) return ref;
      const e = extOf(abs);
      return `/channel/${chId}/p/${register(chId, abs)}${e ? '.' + e : ''}${tq}`;
    };
    return text.split(/\r?\n/).map((line) => {
      const t = line.trim();
      if (!t) return line;
      if (t.startsWith('#')) return line.replace(/URI="([^"]*)"/g, (_, u) => (u ? `URI="${conv(u)}"` : _));
      return conv(t);
    }).join('\n') + '\n';
  }

  function sendText(res, status, body, type = 'text/plain; charset=utf-8') {
    res.writeHead(status, { 'content-type': type, 'cache-control': 'no-store' });
    res.end(body);
  }

  async function servePlaylist(req, res, ch, targetUrl, tq) {
    const { text, url } = await cachedText(targetUrl);
    if (!text.trimStart().startsWith('#EXTM3U')) throw new HttpError(502, 'Kaynak geçerli bir HLS playlist döndürmedi');
    hooks.onOk && hooks.onOk(ch.id);
    res.writeHead(200, { 'content-type': MIME.m3u8, 'cache-control': 'no-cache' });
    res.end(rewrite(text, url, ch.id, tq));
  }

  function evictSeg() {
    const now = Date.now();
    for (const [k, v] of segCache) {
      if (now - v.t > 20000 || segBytes > cfg.segmentCacheBytes) { segBytes -= v.buf.length; segCache.delete(k); } else break;
    }
  }

  function sendBuf(res, e, ext) {
    res.writeHead(200, {
      'content-type': MIME[ext] || e.type || 'application/octet-stream',
      'content-length': e.buf.length, 'cache-control': 'public, max-age=10',
    });
    res.end(e.buf);
  }

  async function bufferFetch(url) {
    const f = await fetchUp(url, { timeoutMs: 20000 });
    try {
      if (!f.res.ok) throw new HttpError(502, `Kaynak HTTP ${f.res.status} döndürdü`);
      const cl = Number(f.res.headers.get('content-length'));
      if (!cl || cl > cfg.maxSegmentBytes) {
        noBuf.add(url); if (noBuf.size > 500) noBuf.delete(noBuf.values().next().value);
        try { await f.res.body.cancel(); } catch { /* yok say */ }
        return null;
      }
      const buf = await readLimited(f.res, cfg.maxSegmentBytes);
      const e = { t: Date.now(), buf, type: f.res.headers.get('content-type') };
      segCache.set(url, e); segBytes += buf.length; evictSeg();
      return e;
    } finally { f.release(); }
  }

  async function streamDirect(req, res, url, ext) {
    const ac = new AbortController();
    res.on('close', () => ac.abort());
    const h = {};
    if (req.headers.range) h.range = req.headers.range;
    const f = await fetchUp(url, { headers: h, timeoutMs: 30000, signal: ac.signal });
    if (!f.res.ok) { f.release(); throw new HttpError(502, `Kaynak HTTP ${f.res.status} döndürdü`); }
    const out = { 'content-type': MIME[ext] || f.res.headers.get('content-type') || 'application/octet-stream', 'cache-control': 'public, max-age=10' };
    for (const k of ['content-length', 'content-range', 'accept-ranges']) { const v = f.res.headers.get(k); if (v) out[k] = v; }
    res.writeHead(f.res.status, out);
    if (!f.res.body) { f.release(); return res.end(); }
    pipeline(Readable.fromWeb(f.res.body), res, () => f.release());
  }

  async function serveSub(req, res, ch, key, tq) {
    const url = lookup(ch.id, key);
    if (!url) throw new HttpError(404, 'Bilinmeyen kaynak (playlist yenilenmeli)');
    const ext = extOf(url);
    if (ext === 'm3u8') return servePlaylist(req, res, ch, url, tq);
    const hit = segCache.get(url);
    if (hit && !req.headers.range && Date.now() - hit.t < 20000) return sendBuf(res, hit, ext);
    if (cfg.segmentCacheBytes > 0 && !req.headers.range && !noBuf.has(url)) {
      let p = inflight.get(url);
      if (!p) { p = bufferFetch(url).finally(() => inflight.delete(url)); inflight.set(url, p); }
      const e = await p;
      if (e) return sendBuf(res, e, ext);
    }
    return streamDirect(req, res, url, ext);
  }

  /** Yalnızca kick.com'un herkese açık kanal bilgisini okur (bot korumasını aşmaya çalışmaz). */
  async function resolveKick(user) {
    if (!/^[A-Za-z0-9_-]{1,40}$/.test(user)) throw new HttpError(502, 'Geçersiz Kick kullanıcı adı');
    const f = await fetchUp(`https://kick.com/api/v2/channels/${user}`, { headers: { accept: 'application/json' } });
    try {
      if (!f.res.ok) throw new HttpError(502, `Kick, otomatik çözümlemeyi reddetti (HTTP ${f.res.status}); elle M3U8 adresi gerekir`);
      let j;
      try { j = JSON.parse((await readLimited(f.res, 512 * 1024)).toString('utf8')); } catch { throw new HttpError(502, 'Kick yanıtı okunamadı (bot koruması olabilir)'); }
      const url = (j && (j.playback_url || (j.livestream && j.livestream.playback_url))) || '';
      if (!j || !j.livestream) throw new HttpError(503, 'Kanal şu an yayında değil');
      if (!/^https:\/\//.test(url)) throw new HttpError(502, 'Kick yanıtında oynatma adresi bulunamadı');
      return url;
    } finally { f.release(); }
  }

  async function probe(url) {
    const { text } = await fetchText(url);
    if (!text.trimStart().startsWith('#EXTM3U')) throw new HttpError(502, 'Kaynak geçerli bir HLS playlist döndürmedi');
    return true;
  }

  return { servePlaylist, serveSub, probe, resolveKick, sendText, rewrite, HttpError, stats: () => ({ activeUpstream: active, segCacheBytes: segBytes }) };
}

module.exports = { createProxy, HttpError };
