'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { detectFfmpeg } = require('./health');
const { assertSafeUrl, scrub } = require('./net');

const BACKOFF = [5000, 15000, 45000];

function createFfmpeg(cfg, hooks = {}) {
  const procs = new Map(); // id -> {child, stopping, restarts, startedAt, timer, lastErr}
  let janitor = null;

  const dirOf = (id) => path.join(cfg.hlsDir, `ch${id}`);
  const rm = (d) => { try { fs.rmSync(d, { recursive: true, force: true }); } catch { /* yok say */ } };

  function isRunning(id) { const p = procs.get(id); return !!(p && p.child && !p.stopping && p.child.exitCode === null); }
  function count() { let n = 0; for (const id of procs.keys()) if (isRunning(id)) n++; return n; }
  function info(id) {
    const p = procs.get(id);
    return { running: isRunning(id), restarts: p ? p.restarts : 0, startedAt: p && p.startedAt ? new Date(p.startedAt).toISOString() : null };
  }

  function buildArgs(url, id) {
    const d = dirOf(id);
    return [
      '-hide_banner', '-loglevel', 'warning', '-nostdin',
      '-protocol_whitelist', 'http,https,tcp,tls,crypto',
      '-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '5',
      '-rw_timeout', '15000000',
      '-i', url,
      '-c', 'copy',
      '-f', 'hls',
      '-hls_time', String(cfg.hlsSegmentSeconds),
      '-hls_list_size', String(cfg.hlsListSize),
      '-hls_flags', 'delete_segments+omit_endlist',
      '-hls_segment_filename', path.join(d, 'seg_%05d.ts'),
      path.join(d, 'index.m3u8'),
    ];
  }

  async function start(ch, { auto = false } = {}) {
    if (ch.mode !== 'ffmpeg') throw new Error('Bu kanal FFmpeg modunda değil (CHANNEL_n_MODE=ffmpeg)');
    if (!ch.sourceUrl) throw new Error('Kaynak URL tanımlı değil');
    if (isRunning(ch.id)) throw new Error('Bu kanal için süreç zaten çalışıyor');
    if (!detectFfmpeg(cfg.ffmpegPath).available) throw new Error('FFmpeg bulunamadı; proxy modunu kullanın');
    if (count() >= cfg.ffmpegMaxProcs) throw new Error(`Eşzamanlı FFmpeg sınırına ulaşıldı (${cfg.ffmpegMaxProcs})`);
    const rssMb = process.memoryUsage().rss / 1048576;
    if (rssMb > cfg.maxRssMb) throw new Error(`Bellek sınırı aşıldı (${Math.round(rssMb)} MB > ${cfg.maxRssMb} MB)`);
    await assertSafeUrl(ch.sourceUrl, { allowPrivate: cfg.allowPrivate });

    const prev = procs.get(ch.id);
    if (prev && prev.timer) clearTimeout(prev.timer);
    const d = dirOf(ch.id);
    rm(d); fs.mkdirSync(d, { recursive: true });

    const state = { child: null, stopping: false, restarts: auto && prev ? prev.restarts : 0, startedAt: Date.now(), timer: null, lastErr: '' };
    procs.set(ch.id, state);
    const child = spawn(cfg.ffmpegPath, buildArgs(ch.sourceUrl, ch.id), { stdio: ['ignore', 'ignore', 'pipe'], shell: false });
    state.child = child;
    child.stderr.on('data', (b) => {
      const line = scrub(b.toString().trim().split('\n').pop());
      if (line) { state.lastErr = line; hooks.onError && hooks.onError(ch.id, `FFmpeg: ${line}`); }
    });
    child.on('error', (e) => { state.lastErr = scrub(e.message); hooks.onError && hooks.onError(ch.id, `FFmpeg başlatılamadı: ${scrub(e.message)}`); });
    child.on('exit', (code, sig) => {
      if (state.stopping) return;
      const ranMs = Date.now() - state.startedAt;
      if (ranMs > 60000) state.restarts = 0;
      hooks.onError && hooks.onError(ch.id, `FFmpeg beklenmedik şekilde sonlandı (kod=${code ?? sig})`);
      if (state.restarts >= BACKOFF.length) {
        hooks.onGiveUp && hooks.onGiveUp(ch.id);
        return;
      }
      const wait = BACKOFF[state.restarts++];
      hooks.onRetry && hooks.onRetry(ch.id, state.restarts, wait);
      state.timer = setTimeout(() => { start(ch, { auto: true }).catch((e) => hooks.onError && hooks.onError(ch.id, scrub(e.message))); }, wait);
    });
    ensureJanitor();
    return info(ch.id);
  }

  function stop(id) {
    const p = procs.get(id);
    if (!p) return false;
    p.stopping = true;
    if (p.timer) clearTimeout(p.timer);
    if (p.child && p.child.exitCode === null) {
      p.child.kill('SIGTERM');
      const c = p.child;
      setTimeout(() => { if (c.exitCode === null) c.kill('SIGKILL'); }, 3000).unref();
    }
    procs.delete(id);
    setTimeout(() => rm(dirOf(id)), 500).unref();
    return true;
  }

  function stopAll() { for (const id of [...procs.keys()]) stop(id); }

  /** Eski segmentleri ve yetim dizinleri temizler. */
  function sweep(maxAgeMs = 120000) {
    let root;
    try { root = fs.readdirSync(cfg.hlsDir); } catch { return 0; }
    let removed = 0;
    for (const name of root) {
      const m = /^ch(\d+)$/.exec(name);
      const full = path.join(cfg.hlsDir, name);
      if (!m) continue;
      if (!isRunning(Number(m[1]))) { rm(full); removed++; continue; }
      for (const f of fs.readdirSync(full)) {
        if (f === 'index.m3u8') continue;
        try {
          if (Date.now() - fs.statSync(path.join(full, f)).mtimeMs > maxAgeMs) { fs.rmSync(path.join(full, f), { force: true }); removed++; }
        } catch { /* yok say */ }
      }
    }
    return removed;
  }

  function ensureJanitor() {
    if (janitor) return;
    janitor = setInterval(() => sweep(), 60000);
    janitor.unref();
  }

  function cleanupAll() { stopAll(); rm(cfg.hlsDir); if (janitor) { clearInterval(janitor); janitor = null; } }

  return { start, stop, stopAll, isRunning, count, info, dirOf, sweep, cleanupAll, ensureJanitor, buildArgs };
}

module.exports = { createFfmpeg };
