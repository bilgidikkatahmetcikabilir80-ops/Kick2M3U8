'use strict';
const os = require('node:os');
const path = require('node:path');

const MAX_CHANNELS = 5;

function int(v, d, min, max) {
  const n = parseInt(v, 10);
  if (!Number.isFinite(n)) return d;
  return Math.min(max, Math.max(min, n));
}

function parseSource(raw) {
  if (!raw) return { url: '', error: null };
  try {
    const u = new URL(raw);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return { url: '', error: 'Kaynak URL http/https olmalı' };
    if (u.username || u.password) return { url: '', error: 'Kaynak URL kullanıcı bilgisi içeremez' };
    return { url: u.href, error: null };
  } catch {
    return { url: '', error: 'Kaynak URL geçersiz' };
  }
}

/** Ortam değişkenlerinden yapılandırmayı okur. Eksik değerler uygulamayı çökertmez. */
function load(env = process.env) {
  const channels = [];
  for (let i = 1; i <= MAX_CHANNELS; i++) {
    const name = (env[`CHANNEL_${i}_NAME`] || '').trim().slice(0, 80);
    const user = (env[`CHANNEL_${i}_USER`] || '').trim().slice(0, 64);
    const src = parseSource((env[`CHANNEL_${i}_SOURCE_URL`] || '').trim());
    const mode = (env[`CHANNEL_${i}_MODE`] || 'proxy').trim().toLowerCase() === 'ffmpeg' ? 'ffmpeg' : 'proxy';
    const resolve = (env[`CHANNEL_${i}_RESOLVE`] || '').trim().toLowerCase() === 'kick' && /^[A-Za-z0-9_-]{1,40}$/.test(user) ? 'kick' : '';
    channels.push({ id: i, name, user, sourceUrl: src.url, sourceError: src.error, mode, resolve });
  }
  // 5'ten fazla kanal tanımı varsa yok sayılır (ve uyarı olarak raporlanır)
  const ignored = [];
  for (const k of Object.keys(env)) {
    const m = /^CHANNEL_(\d+)_/.exec(k);
    if (m && Number(m[1]) > MAX_CHANNELS && !ignored.includes(Number(m[1]))) ignored.push(Number(m[1]));
  }
  const publicBase = (env.PUBLIC_BASE_URL || '').trim().replace(/\/+$/, '');
  return {
    maxChannels: MAX_CHANNELS,
    channels,
    ignoredChannels: ignored,
    port: int(env.PORT, 3000, 1, 65535),
    host: '0.0.0.0',
    adminPassword: env.ADMIN_PASSWORD || '',
    streamToken: (env.STREAM_TOKEN || '').trim(),
    publicBaseUrl: /^https?:\/\/[^\s]+$/.test(publicBase) ? publicBase : '',
    trustProxy: env.TRUST_PROXY === '1',
    ffmpegPath: env.FFMPEG_PATH || 'ffmpeg',
    ffmpegMaxProcs: int(env.FFMPEG_MAX_PROCS, 2, 1, MAX_CHANNELS),
    hlsSegmentSeconds: int(env.HLS_SEGMENT_SECONDS, 4, 1, 10),
    hlsListSize: int(env.HLS_LIST_SIZE, 6, 3, 20),
    hlsDir: env.HLS_DIR || path.join(os.tmpdir(), 'kick2m3u8'),
    maxRssMb: int(env.MAX_RSS_MB, 400, 64, 8192),
    maxUpstream: int(env.MAX_UPSTREAM_CONNECTIONS, 12, 1, 100),
    upstreamTimeoutMs: int(env.UPSTREAM_TIMEOUT_MS, 15000, 2000, 60000),
    maxPlaylistBytes: 1024 * 1024,
    segmentCacheBytes: int(env.SEGMENT_CACHE_MB, 24, 0, 256) * 1024 * 1024,
    maxSegmentBytes: 6 * 1024 * 1024,
    checkIntervalSec: int(env.CHECK_INTERVAL_SEC, 300, 0, 86400),
    // YALNIZCA testler içindir: özel ağ adreslerine izin verir. Üretimde kullanmayın.
    allowPrivate: env.K2M_ALLOW_PRIVATE === '1',
  };
}

module.exports = { load, MAX_CHANNELS };
