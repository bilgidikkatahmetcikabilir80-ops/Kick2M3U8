'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { createApp } = require('../server');
const { isPrivateIp } = require('../src/net');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'k2m-test-'));
const apps = [], mocks = [];
test.after(async () => { for (const a of apps) await a.shutdown(); for (const m of mocks) m.close(); });

async function boot(env = {}) {
  const app = createApp({ HLS_DIR: tmp(), ...env });
  const addr = await app.listen(0, '127.0.0.1');
  apps.push(app);
  return { app, base: `http://127.0.0.1:${addr.port}` };
}
function mock(handler) {
  return new Promise((resolve) => {
    const s = http.createServer(handler);
    s.listen(0, '127.0.0.1', () => { mocks.push(s); resolve({ url: `http://127.0.0.1:${s.address().port}`, server: s }); });
  });
}
async function login(base, password = 'pw-test') {
  const r = await fetch(base + '/api/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ password }) });
  const j = await r.json();
  return { r, cookie: (r.headers.get('set-cookie') || '').split(';')[0], csrf: j.csrf };
}
const authed = (s) => ({ headers: { cookie: s.cookie, 'x-csrf-token': s.csrf } });

// 1
test('ENV eksikken uygulama açılır, panel parolasız açık, playlist boş', async () => {
  const { base } = await boot({});
  assert.equal((await fetch(base + '/api/health')).status, 200);
  assert.equal((await fetch(base + '/api/channels')).status, 200);
  assert.equal((await fetch(base + '/', { redirect: 'manual' })).status, 200);
  const l = await login(base, 'x');
  assert.equal(l.r.status, 200);
  const pl = await (await fetch(base + '/playlist.m3u')).text();
  assert.equal(pl, '#EXTM3U\n');
});

// 2
test('5 kanal sınırı backend tarafından korunur', async () => {
  const { app, base } = await boot({ ADMIN_PASSWORD: 'pw-test', CHANNEL_6_NAME: 'Altı', CHANNEL_6_SOURCE_URL: 'https://x.example/a.m3u8' });
  assert.equal(app.cfg.channels.length, 5);
  assert.deepEqual(app.cfg.ignoredChannels, [6]);
  assert.equal((await fetch(base + '/channel/6.m3u8')).status, 404);
  const s = await login(base);
  const j = await (await fetch(base + '/api/channels', authed(s))).json();
  assert.equal(j.channels.length, 5);
  assert.equal((await fetch(base + '/api/channels/6/check', { method: 'POST', ...authed(s) })).status, 404);
});

// 3,5,6
test('M3U doğru isimlerle üretilir; panel/API yetkisiz kapalı; kaynak URL sızmaz', async () => {
  const secret = 'https://cdn.example.com/SECRET-TOKEN-123/index.m3u8';
  const { base } = await boot({
    ADMIN_PASSWORD: 'pw-test', PUBLIC_BASE_URL: 'https://app.example/',
    CHANNEL_1_NAME: 'Resurrection Channel', CHANNEL_1_USER: 'resurrection-channel-tv', CHANNEL_1_SOURCE_URL: secret,
    CHANNEL_2_NAME: 'Kaynaksız', CHANNEL_2_USER: 'u2',
    CHANNEL_3_NAME: 'Üç', CHANNEL_3_SOURCE_URL: 'https://cdn.example.com/three.m3u8',
  });
  const pl = await (await fetch(base + '/playlist.m3u')).text();
  assert.equal(pl, '#EXTM3U\n#EXTINF:-1,Resurrection Channel\nhttps://app.example/channel/1.m3u8\n#EXTINF:-1,Üç\nhttps://app.example/channel/3.m3u8\n');
  assert.ok(!pl.includes('Kaynaksız'));
  for (const p of ['/api/channels', '/api/status', '/api/playlist-test']) assert.equal((await fetch(base + p)).status, 401, p);
  const root = await fetch(base + '/', { redirect: 'manual' });
  assert.equal(root.status, 302); assert.equal(root.headers.get('location'), '/login');
  assert.equal((await fetch(base + '/login')).status, 200);
  const s = await login(base);
  assert.equal(s.r.status, 200);
  const hdr = s.r.headers.get('set-cookie');
  assert.match(hdr, /HttpOnly/); assert.match(hdr, /SameSite=Strict/); assert.match(hdr, /Secure/);
  for (const p of ['/api/channels', '/api/status']) {
    const body = await (await fetch(base + p, authed(s))).text();
    assert.ok(!body.includes('SECRET-TOKEN'), p + ' kaynak URL sızdırıyor');
    assert.ok(!body.includes('cdn.example.com'), p + ' kaynak host sızdırıyor');
  }
  const ch = (await (await fetch(base + '/api/channels', authed(s))).json()).channels;
  assert.equal(ch[0].user, 'resurrection-channel-tv'); assert.equal(ch[1].status, 'no_source'); assert.equal(ch[1].m3u8Url, null);
  const t = await (await fetch(base + '/api/playlist-test', authed(s))).json();
  assert.deepEqual([t.valid, t.entries], [true, 2]);
  assert.equal((await fetch(base + '/', authed(s))).status, 200);
});

test('CSRF ve giriş denemesi sınırı', async () => {
  const { base } = await boot({ ADMIN_PASSWORD: 'pw-test' });
  const s = await login(base);
  const noCsrf = await fetch(base + '/api/logout', { method: 'POST', headers: { cookie: s.cookie } });
  assert.equal(noCsrf.status, 403);
  const badOrigin = await fetch(base + '/api/logout', { method: 'POST', headers: { cookie: s.cookie, 'x-csrf-token': s.csrf, origin: 'https://evil.example' } });
  assert.equal(badOrigin.status, 403);
  let last;
  for (let i = 0; i < 6; i++) last = (await login(base, 'yanlis' + i)).r.status;
  assert.equal(last, 429);
  assert.equal((await login(base)).r.status, 429, 'doğru parola da kilitliyken reddedilmeli');
});

// 6,8 (proxy + FFmpeg olmadan)
test('Proxy: playlist ve segmentler (göreli+mutlak+alt playlist) çalışır; FFmpeg yokken de', async () => {
  const seg = Buffer.alloc(5000, 7);
  const other = await mock((req, res) => {
    if (req.url === '/abs/segB.ts') { res.writeHead(200, { 'content-type': 'application/octet-stream', 'content-length': 100 }); return res.end(Buffer.alloc(100, 9)); }
    res.writeHead(404); res.end();
  });
  const up = await mock((req, res) => {
    if (req.url === '/live/index.m3u8') {
      res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl' });
      return res.end(`#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nvariant/media.m3u8\n`);
    }
    if (req.url === '/live/variant/media.m3u8') {
      res.writeHead(200, { 'content-type': 'application/vnd.apple.mpegurl' });
      return res.end(`#EXTM3U\n#EXT-X-TARGETDURATION:2\n#EXT-X-KEY:METHOD=AES-128,URI="k.key"\n#EXTINF:2,\nsegA.ts?sig=abc\n#EXTINF:2,\n${other.url}/abs/segB.ts\n`);
    }
    if (req.url === '/live/variant/k.key') { res.writeHead(200); return res.end('0123456789abcdef'); }
    if (req.url.startsWith('/live/variant/segA.ts')) { res.writeHead(200, { 'content-length': seg.length }); return res.end(seg); }
    res.writeHead(404); res.end();
  });
  const { app, base } = await boot({ K2M_ALLOW_PRIVATE: '1', FFMPEG_PATH: '/nonexistent/ffmpeg', CHANNEL_1_NAME: 'T', CHANNEL_1_SOURCE_URL: up.url + '/live/index.m3u8', ADMIN_PASSWORD: 'pw-test' });
  const master = await fetch(base + '/channel/1.m3u8');
  assert.equal(master.status, 200);
  assert.equal(master.headers.get('content-type'), 'application/vnd.apple.mpegurl');
  const mText = await master.text();
  const subPath = mText.split('\n').find((l) => l.startsWith('/channel/1/p/'));
  assert.ok(subPath && subPath.endsWith('.m3u8') && !mText.includes('127.0.0.1'));
  const media = await (await fetch(base + subPath)).text();
  assert.ok(!media.includes('127.0.0.1'), 'kaynak adresi istemciye sızmamalı');
  const paths = media.split('\n').filter((l) => l.includes('/channel/1/p/')).map((l) => (l.match(/(\/channel\/1\/p\/[A-Za-z0-9_-]+(?:\.[a-z0-9]+)?)/) || [])[1]);
  assert.equal(paths.length, 3);
  const keyRes = await fetch(base + paths[0]); assert.equal(await keyRes.text(), '0123456789abcdef');
  const a = await fetch(base + paths[1]);
  assert.equal(a.status, 200); assert.equal(a.headers.get('content-type'), 'video/mp2t');
  assert.equal(Buffer.compare(Buffer.from(await a.arrayBuffer()), seg), 0);
  const b = await fetch(base + paths[2]); assert.equal((await b.arrayBuffer()).byteLength, 100);
  // açık proxy yok
  assert.equal((await fetch(base + '/channel/1/p/AAAAAAAAAAAAAAAA')).status, 404);
  assert.equal((await fetch(base + '/channel/1/p/' + encodeURIComponent(up.url))).status, 404);
  // FFmpeg yok: başlatma temiz hata verir
  const s = await login(base);
  assert.equal((await (await fetch(base + '/api/status', authed(s))).json()).system.ffmpeg.available, false);
  const ch = await (await fetch(base + '/api/channels', authed(s))).json();
  assert.equal(ch.channels[0].status, 'running');
  assert.equal((await fetch(base + '/api/channels/1/ffmpeg/start', { method: 'POST', ...authed(s) })).status, 409);
  app.ffm.stopAll();
});

// 7
test('Erişilemeyen kaynak: 502 ve panelde "unreachable"', async () => {
  const dead = await mock(() => {}); const port = dead.server.address().port; dead.server.close();
  const { base } = await boot({ K2M_ALLOW_PRIVATE: '1', CHANNEL_1_NAME: 'Ölü', CHANNEL_1_SOURCE_URL: `http://127.0.0.1:${port}/x.m3u8`, ADMIN_PASSWORD: 'pw-test' });
  const r = await fetch(base + '/channel/1.m3u8');
  assert.equal(r.status, 502);
  const msg = await r.text(); assert.match(msg, /erişilemedi/); assert.ok(!msg.includes('127.0.0.1'));
  const s = await login(base);
  const ch = (await (await fetch(base + '/api/channels', authed(s))).json()).channels[0];
  assert.equal(ch.status, 'unreachable');
  const bad = await mock((q, res) => { res.writeHead(200); res.end('<html>değil</html>'); });
  const b2 = await boot({ K2M_ALLOW_PRIVATE: '1', CHANNEL_1_NAME: 'Bozuk', CHANNEL_1_SOURCE_URL: bad.url + '/x.m3u8' });
  assert.equal((await fetch(b2.base + '/channel/1.m3u8')).status, 502);
  const e404 = await fetch(base + '/channel/2.m3u8'); assert.equal(e404.status, 503);
});

// 11
test('SSRF: özel ağ adresleri engellenir', async () => {
  for (const ip of ['127.0.0.1', '10.1.2.3', '192.168.0.1', '172.16.5.5', '169.254.169.254', '0.0.0.0', '100.64.0.1', '::1', 'fd00::1', 'fe80::1', '::ffff:127.0.0.1', '::ffff:7f00:1']) assert.ok(isPrivateIp(ip), ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '2606:4700:4700::1111']) assert.ok(!isPrivateIp(ip), ip);
  const hit = []; const up = await mock((q, res) => { hit.push(q.url); res.writeHead(200); res.end('#EXTM3U\n'); });
  const { base } = await boot({ CHANNEL_1_NAME: 'SSRF', CHANNEL_1_SOURCE_URL: up.url + '/x.m3u8', CHANNEL_2_NAME: 'Meta', CHANNEL_2_SOURCE_URL: 'http://169.254.169.254/latest/meta-data/', CHANNEL_3_NAME: 'F', CHANNEL_3_SOURCE_URL: 'file:///etc/passwd' });
  assert.equal((await fetch(base + '/channel/1.m3u8')).status, 502);
  assert.equal((await fetch(base + '/channel/2.m3u8')).status, 502);
  assert.equal((await fetch(base + '/channel/3.m3u8')).status, 503);
  assert.equal(hit.length, 0, 'özel adrese istek gitmemeli');
  // yönlendirme ile SSRF
  const redir = await mock((q, res) => { res.writeHead(302, { location: 'http://127.0.0.1:1/' }); res.end(); });
  const { createProxy } = require('../src/proxy');
  const p = createProxy({ allowPrivate: false, maxUpstream: 5, upstreamTimeoutMs: 3000, maxPlaylistBytes: 1e6, segmentCacheBytes: 0, maxSegmentBytes: 1e6 });
  await assert.rejects(() => p.probe('http://localhost:' + redir.server.address().port + '/'), /engellendi/);
});

// 9
test('FFmpeg modu: -c copy, segment yönlendirme, eski dosya/dizin temizliği, durdurma', async (t) => {
  if (spawnSync('ffmpeg', ['-version']).status !== 0) return t.skip('ffmpeg yok');
  const src = tmp();
  const gen = spawnSync('ffmpeg', ['-v', 'error', '-f', 'lavfi', '-i', 'testsrc=duration=6:size=160x120:rate=10', '-c:v', 'mpeg2video', '-g', '10', '-f', 'hls', '-hls_time', '2', '-hls_list_size', '0', '-hls_segment_filename', path.join(src, 's%d.ts'), path.join(src, 'index.m3u8')]);
  assert.equal(gen.status, 0, String(gen.stderr));
  const up = await mock((req, res) => {
    const f = path.join(src, path.basename(req.url.split('?')[0]));
    if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
    const buf = fs.readFileSync(f);
    if (f.endsWith('s2.ts')) { // kaynak "canlı" kalsın: son segment yarıda takılı kalır
      res.writeHead(200); res.write(buf.subarray(0, Math.floor(buf.length * 0.6)));
      return setTimeout(() => res.destroy(), 20000).unref();
    }
    res.writeHead(200); res.end(buf);
  });
  const { app, base } = await boot({ K2M_ALLOW_PRIVATE: '1', ADMIN_PASSWORD: 'pw-test', HLS_SEGMENT_SECONDS: '1', CHANNEL_1_NAME: 'FF', CHANNEL_1_MODE: 'ffmpeg', CHANNEL_1_SOURCE_URL: up.url + '/index.m3u8', CHANNEL_2_NAME: 'P', CHANNEL_2_SOURCE_URL: up.url + '/index.m3u8' });
  const args = app.ffm.buildArgs('http://x/a.m3u8', 1);
  assert.ok(args.join(' ').includes('-c copy'));
  const s = await login(base);
  assert.equal((await fetch(base + '/channel/1.m3u8')).status, 503);
  assert.equal((await fetch(base + '/api/channels/2/ffmpeg/start', { method: 'POST', ...authed(s) })).status, 409, 'proxy kanalında FFmpeg başlamamalı');
  assert.equal((await fetch(base + '/api/channels/1/ffmpeg/start', { method: 'POST', ...authed(s) })).status, 200);
  assert.equal((await fetch(base + '/api/channels/1/ffmpeg/start', { method: 'POST', ...authed(s) })).status, 409, 'aynı kanalda ikinci süreç olmamalı');
  const idx = path.join(app.ffm.dirOf(1), 'index.m3u8');
  for (let i = 0; i < 60 && !fs.existsSync(idx); i++) await new Promise((r) => setTimeout(r, 250));
  assert.ok(fs.existsSync(idx), 'index.m3u8 üretilmedi');
  const pl = await (await fetch(base + '/channel/1.m3u8')).text();
  const segLine = pl.split('\n').find((l) => l.startsWith('/channel/1/f/seg_'));
  assert.ok(segLine, pl);
  const sg = await fetch(base + segLine); assert.equal(sg.status, 200); assert.ok((await sg.arrayBuffer()).byteLength > 100);
  assert.equal((await fetch(base + '/channel/1/f/..%2F..%2Fetc%2Fpasswd')).status, 404);
  // temizlik: eski segment silinir, taze olan kalır
  const old = path.join(app.ffm.dirOf(1), 'seg_99998.ts'), fresh = path.join(app.ffm.dirOf(1), 'seg_99999.ts');
  fs.writeFileSync(old, 'x'); fs.writeFileSync(fresh, 'x');
  const past = new Date(Date.now() - 10 * 60 * 1000); fs.utimesSync(old, past, past);
  app.ffm.sweep(120000);
  assert.ok(!fs.existsSync(old)); assert.ok(fs.existsSync(fresh));
  const orphan = path.join(app.cfg.hlsDir, 'ch4'); fs.mkdirSync(orphan); fs.writeFileSync(path.join(orphan, 'seg_00001.ts'), 'x');
  app.ffm.sweep(); assert.ok(!fs.existsSync(orphan), 'yetim dizin temizlenmeli');
  assert.equal(app.ffm.count(), 1);
  assert.equal((await fetch(base + '/api/channels/1/ffmpeg/stop', { method: 'POST', ...authed(s) })).status, 200);
  assert.equal(app.ffm.count(), 0);
  await new Promise((r) => setTimeout(r, 900));
  assert.ok(!fs.existsSync(app.ffm.dirOf(1)), 'durdurunca dizin silinmeli');
});

// 10
test('Yeniden başlatmada yapılandırma ENV’den tekrar yüklenir', async () => {
  const env = { ADMIN_PASSWORD: 'pw-test', CHANNEL_1_NAME: 'Kalıcı', CHANNEL_1_SOURCE_URL: 'https://cdn.example.com/a.m3u8' };
  const a = await boot(env); await a.app.shutdown();
  const b = await boot(env);
  const pl = await (await fetch(b.base + '/playlist.m3u')).text();
  assert.match(pl, /Kalıcı/);
});
